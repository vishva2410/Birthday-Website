import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle2, XCircle, Trophy, ArrowRight } from 'lucide-react';

const questions = [
  {
    question: "What's his favorite drink?",
    options: [
      "Black Coffee",
      "Green Tea",
      "Coffee Chips",
      "Both Green Tea & Coffee Chips"
    ],
    correctAnswer: 3
  },
  {
    question: "Which bike does he own?",
    options: [
      "Bajaj Pulsar",
      "Royal Enfield",
      "Yamaha R15",
      "Harley Davidson"
    ],
    correctAnswer: 1
  },
  {
    question: "When did he become a father?",
    options: [
      "2000",
      "2003",
      "2005",
      "2008"
    ],
    correctAnswer: 2
  },
  {
    question: "Which business did he start after closing Tulsi Tex Tiles?",
    options: [
      "GT Electronics",
      "GR Textile",
      "SK Fashion Hub",
      "Phoenix Clothing"
    ],
    correctAnswer: 1
  },
  {
    question: "Which of these hobbies does he love the most?",
    options: [
      "Painting",
      "Watching New Movies",
      "Gardening",
      "Playing Cricket"
    ],
    correctAnswer: 1
  }
];

export function Quiz() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [showResults, setShowResults] = useState(false);

  const handleAnswer = (index: number) => {
    if (selectedAnswer !== null) return;
    setSelectedAnswer(index);
    if (index === questions[currentQuestion].correctAnswer) {
      setScore(score + 1);
    }
  };

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
    } else {
      setShowResults(true);
    }
  };

  const getScoreMessage = () => {
    const percentage = (score / questions.length) * 100;
    if (percentage === 100) return "Perfect! You know Shashikanth very well!";
    if (percentage >= 80) return "Great job! You're a close friend!";
    if (percentage >= 60) return "Not bad! You know quite a bit about Shashikanth!";
    return "Keep learning more about Shashikanth!";
  };

  return (
    <div className="py-20 bg-black/30 backdrop-blur-sm">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-4xl md:text-5xl font-serif text-center text-gold-light mb-16"
        >
          How Well Do You Know Shashikanth?
        </motion.h2>

        <div className="max-w-2xl mx-auto">
          <AnimatePresence mode="wait">
            {!showResults ? (
              <motion.div
                key="question"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.4 }}
                className="bg-black/40 p-8 rounded-xl backdrop-blur-sm border border-gold-light/20"
              >
                <div className="mb-8">
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-gold-light">Question {currentQuestion + 1}/{questions.length}</span>
                    <span className="text-gold-light">Score: {score}</span>
                  </div>
                  <h3 className="text-xl text-white mb-6">{questions[currentQuestion].question}</h3>
                  <div className="space-y-4">
                    {questions[currentQuestion].options.map((option, index) => (
                      <button
                        key={index}
                        onClick={() => handleAnswer(index)}
                        disabled={selectedAnswer !== null}
                        className={`w-full p-4 rounded-lg text-left transition-all transform hover:scale-[1.02] ${
                          selectedAnswer === null
                            ? 'bg-white/10 hover:bg-white/20'
                            : selectedAnswer === index
                            ? index === questions[currentQuestion].correctAnswer
                              ? 'bg-green-500/20 border-2 border-green-500'
                              : 'bg-red-500/20 border-2 border-red-500'
                            : index === questions[currentQuestion].correctAnswer
                            ? 'bg-green-500/20 border-2 border-green-500'
                            : 'bg-white/10'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-white">{option}</span>
                          {selectedAnswer !== null && (
                            index === questions[currentQuestion].correctAnswer ? (
                              <CheckCircle2 className="w-6 h-6 text-green-500" />
                            ) : selectedAnswer === index ? (
                              <XCircle className="w-6 h-6 text-red-500" />
                            ) : null
                          )}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
                {selectedAnswer !== null && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex justify-end"
                  >
                    <button
                      onClick={nextQuestion}
                      className="bg-gold-light text-black px-6 py-3 rounded-lg font-semibold flex items-center gap-2 hover:bg-gold-dark transition-colors"
                    >
                      {currentQuestion === questions.length - 1 ? 'Show Results' : 'Next Question'}
                      <ArrowRight className="w-5 h-5" />
                    </button>
                  </motion.div>
                )}
              </motion.div>
            ) : (
              <motion.div
                key="results"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-black/40 p-8 rounded-xl backdrop-blur-sm border border-gold-light/20 text-center"
              >
                <Trophy className="w-16 h-16 text-gold-light mx-auto mb-6" />
                <h3 className="text-2xl font-serif text-gold-light mb-4">Quiz Complete!</h3>
                <p className="text-xl text-white mb-4">Your Score: {score}/{questions.length}</p>
                <p className="text-lg text-gray-300 mb-8">{getScoreMessage()}</p>
                <button
                  onClick={() => {
                    setCurrentQuestion(0);
                    setSelectedAnswer(null);
                    setScore(0);
                    setShowResults(false);
                  }}
                  className="bg-gold-light text-black px-6 py-3 rounded-lg font-semibold hover:bg-gold-dark transition-colors"
                >
                  Try Again
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}