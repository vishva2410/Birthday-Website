import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Gift, Heart, Star, Sparkles } from 'lucide-react';

const memories = [
  "First Royal Enfield ride",
  "Opening GR Textile",
  "Family vacation memories",
  "Movie nights with friends",
  "Tech gadget shopping sprees",
  "Coffee and conversations",
  "Birthday celebrations",
  "Festival gatherings"
];

export function Games() {
  const [selectedMemory, setSelectedMemory] = useState<string | null>(null);
  const [matchedPairs, setMatchedPairs] = useState<number>(0);
  const [showWishAnimation, setShowWishAnimation] = useState(false);

  const handleMemoryClick = (memory: string) => {
    setSelectedMemory(memory);
    setShowWishAnimation(true);
    setTimeout(() => setShowWishAnimation(false), 2000);
  };

  return (
    <div className="py-20 bg-gradient-to-b from-purple-900/30 to-gold-dark/30 backdrop-blur-sm">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-4xl md:text-5xl font-serif text-center text-gold-light mb-16"
        >
          Memory Games & Wishes
        </motion.h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {/* Memory Match Game */}
          <div className="bg-black/40 p-6 rounded-xl backdrop-blur-sm border border-gold-light/20">
            <h3 className="text-2xl font-serif text-gold-light mb-6 flex items-center gap-2">
              <Star className="w-6 h-6" />
              Memory Lane
            </h3>
            <div className="grid grid-cols-2 gap-4">
              {memories.slice(0, 6).map((memory, index) => (
                <motion.button
                  key={index}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => handleMemoryClick(memory)}
                  className={`p-4 rounded-lg text-center transition-colors ${
                    selectedMemory === memory
                      ? 'bg-gradient-to-r from-purple-500 to-gold-light text-white'
                      : 'bg-white/10 hover:bg-white/20 text-white'
                  }`}
                >
                  {memory}
                </motion.button>
              ))}
            </div>
          </div>

          {/* Birthday Wish Generator */}
          <div className="bg-black/40 p-6 rounded-xl backdrop-blur-sm border border-gold-light/20">
            <h3 className="text-2xl font-serif text-gold-light mb-6 flex items-center gap-2">
              <Gift className="w-6 h-6" />
              Wish Generator
            </h3>
            <div className="relative h-[300px] flex items-center justify-center">
              <AnimatePresence>
                {showWishAnimation && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.5 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 1.5 }}
                    className="absolute inset-0 flex items-center justify-center"
                  >
                    <div className="text-center">
                      <Sparkles className="w-12 h-12 text-gold-light mx-auto mb-4" />
                      <p className="text-2xl text-white font-serif">
                        Happy 50th Birthday!
                      </p>
                      <p className="text-gold-light mt-2">
                        Here's to more {selectedMemory?.toLowerCase() || 'memories'}!
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
              {!showWishAnimation && (
                <p className="text-white text-center">
                  Click a memory to generate a special birthday wish!
                </p>
              )}
            </div>
          </div>

          {/* Love Meter */}
          <div className="bg-black/40 p-6 rounded-xl backdrop-blur-sm border border-gold-light/20 md:col-span-2">
            <h3 className="text-2xl font-serif text-gold-light mb-6 flex items-center gap-2">
              <Heart className="w-6 h-6" />
              Birthday Love Meter
            </h3>
            <div className="h-6 bg-white/10 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: "0%" }}
                animate={{ width: "100%" }}
                transition={{ duration: 3, repeat: Infinity }}
                className="h-full bg-gradient-to-r from-red-500 via-gold-light to-purple-500"
              />
            </div>
            <p className="text-center text-white mt-4">
              The love keeps growing! ❤️
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}