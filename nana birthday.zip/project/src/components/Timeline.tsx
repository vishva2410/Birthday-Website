import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, Heart, Store, Recycle as Motorcycle, Laptop, Coffee, Film, Cake } from 'lucide-react';

const timelineEvents = [
  {
    date: "February 13, 1975",
    title: "The Beginning",
    description: "Born in India, starting a journey full of adventure, innovation, and kindness.",
    icon: Calendar
  },
  {
    date: "2005",
    title: "The Best Chapter Begins!",
    description: "Married and became a father to twins, marking the start of a beautiful family journey.",
    icon: Heart
  },
  {
    date: "2016",
    title: "A New Business Venture",
    description: "Tulsi Tex Tiles closed, paving the way for a new chapter with GR Textile, his own business.",
    icon: Store
  },
  {
    date: "2019",
    title: "The Biker Life Begins!",
    description: "Bought a Royal Enfield, fulfilling a long-time dream and hitting the roads in style.",
    icon: Motorcycle
  },
  {
    date: "2020",
    title: "The Tech Guru Awakens",
    description: "Developed a deep love for laptops, gadgets, and technology, always exploring the latest trends.",
    icon: Laptop
  },
  {
    date: "2022",
    title: "Exploring New Tastes & Adventures",
    description: "Fell in love with green tea and coffee chips, always open to trying new things.",
    icon: Coffee
  },
  {
    date: "2023",
    title: "Movie Buff Era",
    description: "Started watching every new movie that came out, making it a weekly ritual.",
    icon: Film
  },
  {
    date: "2025",
    title: "Celebrating 50 Amazing Years!",
    description: "A milestone moment! A lifetime of achievements, memories, and a future full of adventures.",
    icon: Cake
  }
];

export function Timeline() {
  return (
    <div className="py-20 bg-black/30 backdrop-blur-sm">
      <div className="container mx-auto px-4">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-4xl md:text-5xl font-serif text-center text-gold-light mb-16"
        >
          Journey Through Time
        </motion.h2>
        
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-gold-light/30" />
          
          {/* Timeline events */}
          {timelineEvents.map((event, index) => {
            const Icon = event.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className={`relative flex items-center mb-12 ${
                  index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                }`}
              >
                {/* Timeline dot */}
                <div className="absolute left-4 md:left-1/2 transform -translate-x-2 md:-translate-x-3">
                  <div className="w-4 h-4 md:w-6 md:h-6 bg-gold-light rounded-full" />
                </div>
                
                {/* Content */}
                <div className={`ml-12 md:ml-0 md:w-1/2 ${
                  index % 2 === 0 ? 'md:pr-12' : 'md:pl-12'
                }`}>
                  <div className="bg-black/40 p-6 rounded-xl backdrop-blur-sm border border-gold-light/20 hover:border-gold-light/40 transition-colors">
                    <div className="flex items-center gap-4 mb-3">
                      <Icon className="w-6 h-6 text-gold-light" />
                      <span className="text-gold-light font-semibold">{event.date}</span>
                    </div>
                    <h3 className="text-xl font-serif text-gold-light mb-2">{event.title}</h3>
                    <p className="text-gray-300">{event.description}</p>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}