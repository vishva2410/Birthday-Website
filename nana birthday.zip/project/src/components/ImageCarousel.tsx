import React from 'react';
import { motion } from 'framer-motion';

export function ImageCarousel() {
  return (
    <div className="relative">
      <motion.div
        className="relative"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <img
          src="https://raw.githubusercontent.com/Shashikanth1997/birthday-images/main/shashi1.jpg"
          alt="Shashikanth in a green traditional outfit"
          className="w-full aspect-square object-cover rounded-2xl border-4 border-gold-light shadow-2xl shadow-gold-light/20"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent rounded-2xl">
          <div className="absolute bottom-0 left-0 right-0 p-4 text-center">
            <p className="text-white text-lg font-serif bg-black/40 backdrop-blur-sm rounded-lg p-2">
              The man of the moment
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}