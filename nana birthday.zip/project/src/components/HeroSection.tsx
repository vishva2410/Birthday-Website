import React from 'react';
import { motion } from 'framer-motion';
import { CountdownTimer } from './CountdownTimer';
import { Gift } from 'lucide-react';
import { ImageCarousel } from './ImageCarousel';

export function HeroSection() {
  return (
    <div className="relative min-h-screen bg-gradient-to-b from-black to-gray-900 text-white overflow-hidden">
      {/* Golden decorative elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-0 w-64 h-64 bg-gold-light/10 rounded-full blur-3xl transform -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-gold-light/10 rounded-full blur-3xl transform translate-x-1/2 translate-y-1/2" />
      </div>

      <div className="container mx-auto px-4 py-20 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <h1 className="font-serif text-6xl md:text-7xl lg:text-8xl mb-6 bg-gradient-to-r from-gold-light via-gold-dark to-gold-light bg-clip-text text-transparent">
            Happy 50th Birthday
          </h1>
          <h2 className="font-serif text-4xl md:text-5xl text-gold-light mb-8">
            Guduguntla Shashikanth
          </h2>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative"
            >
              <ImageCarousel />
              <Gift className="absolute -top-6 -right-6 w-12 h-12 text-gold-light animate-float" />
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="text-center md:text-left"
            >
              <h3 className="text-2xl font-serif text-gold-light mb-6">
                Celebrating Half a Century of Amazing Moments
              </h3>
              <p className="text-lg mb-8 text-gray-300">
                Join us in celebrating this milestone birthday of an incredible father, 
                tech enthusiast, and adventure seeker.
              </p>
              <div className="bg-black/50 p-6 rounded-xl backdrop-blur-sm">
                <h4 className="text-xl text-gold-light mb-4">Countdown to the Big Day</h4>
                <CountdownTimer />
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}