import React, { useEffect, useState } from 'react';
import Confetti from 'react-confetti';
import { HeroSection } from './components/HeroSection';
import { Timeline } from './components/Timeline';
import { Quiz } from './components/Quiz';
import { Games } from './components/Games';

function App() {
  const [showConfetti, setShowConfetti] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowConfetti(false);
    }, 8000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-black via-purple-900/20 to-black">
      {showConfetti && (
        <Confetti
          width={window.innerWidth}
          height={window.innerHeight}
          colors={['#FFD700', '#CFB53B', '#B8860B', '#FFFFFF', '#9333EA']}
          numberOfPieces={200}
        />
      )}
      <HeroSection />
      <Timeline />
      <Quiz />
      <Games />
    </div>
  );
}

export default App;